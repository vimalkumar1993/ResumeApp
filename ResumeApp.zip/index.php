<html>
<head><title>Vimal</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" charset="utf-8">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery-ui.js"></script>
    <script src="assets/js/main.js" type="text/javascript"></script>
</head>
<body oncontextmenu="return false;" onkeydown="if(event.keyCode==123)return false;">
        <div class="layout">
        <div class="page-loader"></div>
        <!--Sidebar-->
        <div class="sideBar" style="display:none">
            <div class="photo-box"><img src="assets/img/user.jpg" style="width: 131px;border-radius:50%"/></div>
            <div class="menu-box">
                <div class="menu-group dashboardMenu active"  onclick="navigateTo('dashboard')">
                    <div class="menu-icon"><i class="fa fa-dashboard"></i></div>Dashboard
                </div>
                <div class="menu-group academicsMenu" onclick="navigateTo('academics')">
                    <div class="menu-icon" ><i class="fa fa-line-chart"></i></div>Career
                </div>
                <div class="menu-group portfolioMenu" onclick="navigateTo('portfolio')">
                    <div class="menu-icon"><i class="fa fa-rocket"></i></div>Portfolio
                </div>
                <div class="menu-group achievementsMenu" onclick="navigateTo('achievements')">
                    <div class="menu-icon"><i class="fa fa-trophy"></i></div>Achievements
                </div>
                <div class="menu-group contactMenu" onclick="navigateTo('contact')">
                    <div class="menu-icon"><i class="fa fa-phone"></i></div>Contact
                </div>
            </div>
        </div>
            <!--Main content-->
            <div class="main-content" id="dashboard" style="display:none">
                <div class="profile">
                    <h1 style="padding-top: 3%;">Hello ! I'm <span style="color:#e26b6b">Vimal</span></h1>
                    <div style="margin-top:-2%;color:#e26b6b;margin-bottom:2%">Full stack developer</div>
                    <div class="description">A professional developer with more than 3 years experience. To turn your beautiful designs into usable websites that respond to various device, user contexts and integrating with database using various platforms. I'm the guy you are probably looking for.</div>
                    <hr style="border:1px solid #f1f1f1">
                </div>
                <div class="body">
                    <div class="row" style="padding-top:4%;padding-left: 1%;">
                        <div style="float:left;width:100%">
                            <div class="boxing">
                                <div class="boxing-header">UI & CMS<div class="arrow"></div></div>
                                <div class="boxing-body">
                                    <div>Photoshop <div class="progress-bar"><div class="skills ps"><span>90%</span></div></div></div>
                                    <div>CorelDraw<div class="progress-bar"><div class="skills cd"><span>80%</span></div></div></div>
                                     <div>Wordpress<div class="progress-bar"><div class="skills wp"><span>70%</span></div></div></div>
                                    <div>Joomla<div class="progress-bar"><div class="skills wp"><span>70%</span></div></div></div>
                                </div>
                            </div>
                            <div class="boxing">
                                <div class="boxing-header">UX<div class="arrow"></div></div>
                                <div class="boxing-body">
                                    <div>HTML5 <div class="progress-bar"><div class="skills ps"><span>90%</span></div></div></div>
                                    <div>CSS3/LESS/SASS<div class="progress-bar"><div class="skills cd"><span>85%</span></div></div></div>
                                    <div>Jquery<div class="progress-bar"><div class="skills jq"><span>80%</span></div></div></div>
                                    <div>Handlebars<div class="progress-bar"><div class="skills hb"><span>70%</span></div></div></div>
                                </div>
                            </div>
                            <div class="boxing">
                                <div class="boxing-header">Backend<div class="arrow"></div></div>
                                <div class="boxing-body">
                                    <div>PHP<div class="progress-bar"><div class="skills ps"><span>90%</span></div></div></div>
                                    <div>Java<div class="progress-bar"><div class="skills cd"><span>80%</span></div></div></div>
                                    <div>MVC Patterns<div class="progress-bar"><div class="skills wp"><span>70%</span></div></div></div>
                                    <div>RESTful WS<div class="progress-bar"><div class="skills wp"><span>70%</span></div></div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        <div class="footer" style="display:none">  
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-skype"></i>
                    <i class="fa fa-linkedin-square"></i>
                </div>
        <!--Academics-->
        <div class="main-content" id="academics" style="display:none">
            <div class="profile" style="height:45%">
               <div class="boxing" style="margin-top: 26px;margin-left: 26px;width:44%;text-align:left;color:#555;height:213px;border-right:5px solid #e26b6b;background: #f9f9f9;
    box-shadow: 1px 1px 2px #d2d2d2;"><div class="arrow-right"></div>
                    <div class="boxing-body" style="font-size:13.5px;line-height:30px;padding-top: 0px;position: relative;bottom: 21px;">
                        <h2 style="padding-left:18px"><i class="fa fa-briefcase"></i> EXPERIENCE</h2>
                        <ul style="list-style-type: square;color:#888">
                            <li>Working as <b>UX Engineer</b> in Exterro R&D, Coimbatore from 2016 to present</li>
                            <li>Worked as <b>Full stack developer</b> in Daemon Softwares & Services from 2014 to 2016</li>
                        </ul>
                    </div>
                </div>
                <div class="timeline">
                    <div class="circle"></div>
                    <div class="circle" style="top:314px"></div>
                </div>
            </div>
            <div class="body" style="height:45%">
                <div class="row" style="padding-top:2%;padding-left: 1%;">
                    <div style="float:right;width:100%">
                        <div class="edu-boxing"><div class="arrow-left"></div>
                    <div class="boxing-body" style="font-size:13.5px;line-height:30px;padding-top: 0px;position: relative;bottom: 21px;">
                        <h2 style="padding-left:18px"><i class="fa fa-graduation-cap"></i> EDUCATION</h2>
                        <ul style="list-style-type: square;color:#888">
                            <li>Completed <b>B.E Computer Science</b> in 2014 with 7.2 CGPA from Sri Ramakrishna Institute of Technology</li>
                            <li>Completed <b>Diploma in Computer Science</b> in 2011 with 93%</li>
                            <li>Completed <b>SSLC</b> in 2008 with 63%</li>
                        </ul>
                    </div>
                </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Portfolio-->
            <div class="main-content" id="portfolio" style="display:none">
            <div class="profile" style="height:90%">
               <ul class="portfolio-tabs">
                    <li class="tab-active">All</li>
                    <li>Design</li>
                    <li>Development</li>
                    <li>Misc</li>
                </ul> 
                <div>Dev in Progress!</div>
            </div>
        </div>
        <!--Achievements-->
        <div class="main-content" id="achievements" style="display:none;overflow-y:auto">
            <div class="profile" style="width:97%;height:90%;padding-left:2%">
                <div class="boxing-header" style="width:175px;padding-top:11px"><i class="fa fa-trophy"></i> ACHIEVEMENTS<div class="arrow-achi"></div>
            </div>
            <div style="text-align:left;padding-top:32px">
                <ul style="width: 900px;line-height: 32px;color:#555">
                    <li>Awarded as <b>“Best Outgoing Student”</b> during the academic year 2011. </li>
                    <li>Presented around 8 papers with one <b>1st prize, two 2nd prize and one third prize</b> in National level symposiums held at various colleges in Tamil Nadu. </li>
                    <li>Participated in 2 National Level Poster Presentation Competitions and won <b>two 1st prizes.</b></li>
                    <li>Participated <b>3 National Level Conferences</b> and <b>2 National Level Seminars</b> held at various colleges in Tamil Nadu.</li>
                    <li>Participated in a National Level Video Presentation and won <b>1st prize</b> held at Sri Ramakrishna Institute of Technology.</li>
                    <li>Published an <b>International Journal</b> titled <b><a target="_blank" href="http://www.ijcaonline.org/archives/volume49/number1/7592-9448">Gesture Recognition using a Touch less Feeler Machine</a></b> in International Journal of Computer Applications.</li>
                    <li>Attended a Gaming competition and won National level <b>3rd prize.</b></li>
                    <li>Displayed Mini Projects in <b>3 National Level Project Exhibitions</b>  held at various colleges in Tamil Nadu.</li>
                </ul>
            </div>
            </div>
        </div>
        <!--Contact-->
        <div class="main-content" id="contact" style="display:none;overflow-y:auto">
            <div class="profile" style="width:97%;height:90%;padding-left:2%">
                <div class="boxing-header" style="width:120px;padding-top:11px"><i class="fa fa-phone"></i>     CONTACT<div class="arrow-achi"></div>
                </div>
                <div class="left-pane" style="color:#555">
                    <div>
                    <h3 style="border-bottom: 0px solid #e26b6b;width: 100px;">LOCATION</h3>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d250646.96827152415!2d76.82714837490758!3d11.01167749112608!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba859af2f971cb5%3A0x2fc1c81e183ed282!2sCoimbatore%2C+Tamil+Nadu!5e0!3m2!1sen!2sin!4v1501739859086" width="450" height="150" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                    <div class="emailBlock">
                        <h3 style="color:#555;margin-bottom: 12px;border-bottom: 0px solid #e26b6b;width: 138px;">GET IN TOUCH</h3>
                        <div class="email" style="padding-bottom:10px;color:#777"><i class="fa fa-envelope-o"></i> vimal.official@yahoo.com</div>
                    </div>
                    <div>
                        <div style="color:#777"><i class="fa fa-phone"></i> +91 9944885108</div>
                    </div>
                </div>
                <div class="right-pane" style="text-align:left;padding-left:583">
                    <h3 style="border-bottom: 0px solid #e26b6b;width: 155px;color:#555">CONTACT FORM</h3>
                    <form id="mailForm" method="post">
                        <div class="form-group">
                            <div><input name="name" id="name" placeholder="Full Name *"/></div>
                        </div>
                        <div class="form-group">
                            <div><input id="email" name="email" placeholder="Email Address *"/></div>
                        </div>
                        <div class="form-group">
                            <div><input id="mobile" name="mobile" placeholder="Mobile *"/></div>
                        </div>
                        <div class="form-group">
                            <div><textarea id="message" name="message" placeholder="Message"></textarea></div>
                        </div>
                        <button class="submitButton" type="submit" id="submitButton" name="submitButton">Send message</button>
                    </form>
                </div>
            </div>
        </div>
    </div> 
</body>
</html>