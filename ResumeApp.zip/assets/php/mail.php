 <?php

        $name=$_POST['name'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $message=$_POST['message'];		
        $from="From: $name<$email>\r\nReturn-path: $email";
        $subject="Contact form message from $name";
        mail("vimal.official@yahoo.com", $subject, $message, $from);
        echo "success";
?>