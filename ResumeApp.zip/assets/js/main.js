function main() {
    this.var1="123";
}

main.prototype=function() {
    onload=function() {
        $( "#chathead-main" ).draggable();
    },
    openNav=function(){
        document.getElementById('sideBar').style.display="block"; 
        $("#sideBar a:first").focus();
    },
    closeNav=function(){
        document.getElementById('sideBar').style.display="none"; 
    },
    showChat=function(){
        document.getElementById('chatbox').style.display="block";
        $(".chatbox-msg input").focus();
    },
    closeChat=function(){
        document.getElementById('chatbox').style.display="none"; 
    }
    return {
        openNav:openNav,
        closeNav:closeNav,
        showChat:showChat,
        closeChat:closeChat
    };
}();

var main=new main();