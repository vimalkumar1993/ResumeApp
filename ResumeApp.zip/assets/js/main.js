function main() {
    this.var1="123";
}

main.prototype=function() {
    navigateTo=function(val) {
        if(!$("."+val+"Menu").hasClass('active')){
           $('.menu-group').removeClass('active');
            $('.'+val+'Menu').addClass('active');
            $(".main-content").slideUp(300);
            $("#"+val).slideDown(300);
            if(val=="dashboard") {
                $(".progress-bar").css({'width':'0px'});
                $(".progress-bar").animate({width:'83%'},"slow");
            }
        }
    }
    return {
        navigateTo:navigateTo
    };
}();

var main=new main();